import { HttpStatus } from '@nestjs/common';
import { UsersService } from './users.service';
import type { Request } from 'express';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    private getClaims;
    private ensureAuthenticated;
    private ensureAdmin;
    getProfile(req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: Record<string, any>;
    }>;
    getPurchases(req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            saleId: any;
            event: {
                id: any;
                name: any;
                from: any;
                to: any;
                location: any;
            } | null;
            batch: {
                id: any;
                name: any;
                price: any;
            } | null;
            quantity: any;
            total: any;
            status: any;
            tickets: any[];
            createdAt: any;
        }[];
    }>;
    getAllUsers(req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            id: string;
            email: string;
            given_name: string;
            family_name: string;
            role: string;
            purchasedTickets: string[];
            soldTickets: string[] | undefined;
            createdAt: string;
        }[];
    }>;
}
