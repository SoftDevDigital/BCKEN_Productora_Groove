"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDirectSaleDto = void 0;
class CreateDirectSaleDto {
    eventId;
    batchId;
    quantity;
    email;
}
exports.CreateDirectSaleDto = CreateDirectSaleDto;
//# sourceMappingURL=create-direct-sale.dto.js.map