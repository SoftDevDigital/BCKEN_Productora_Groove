import { HttpStatus } from '@nestjs/common';
import { SalesService } from './sales.service';
import { PaymentsService } from '../payments/payments.service';
import { BatchesService } from '../batches/batches.service';
import { CreateSaleDto } from './dto/create-sale.dto';
import type { Request } from 'express';
export declare class SalesController {
    private readonly salesService;
    private readonly paymentsService;
    private readonly batchesService;
    constructor(salesService: SalesService, paymentsService: PaymentsService, batchesService: BatchesService);
    private getClaims;
    private ensureAuthenticated;
    private ensureReseller;
    createDirect(dto: CreateSaleDto, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            paymentLink: any;
            id: string;
            eventId: string;
            batchId: string;
            quantity: number;
            type: "direct" | "reseller";
            basePrice: any;
            commission: number;
            total: number;
            status: string;
        };
    }>;
    createReseller(dto: CreateSaleDto, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            paymentLink: any;
            id: string;
            eventId: string;
            batchId: string;
            quantity: number;
            type: "direct" | "reseller";
            basePrice: any;
            commission: number;
            total: number;
            status: string;
        };
    }>;
    handleWebhook(body: any): Promise<{
        statusCode: HttpStatus;
        message: string;
    }>;
}
