"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsController = void 0;
const common_1 = require("@nestjs/common");
const reports_service_1 = require("./reports.service");
let ReportsController = class ReportsController {
    reportsService;
    constructor(reportsService) {
        this.reportsService = reportsService;
    }
    getClaims(req) {
        let claims = null;
        if (req['apiGateway']) {
            const ctx = req['apiGateway'].event.requestContext;
            claims = ctx.authorizer?.jwt?.claims || ctx.authorizer?.claims || null;
        }
        if (!claims) {
            const token = req.headers['authorization']?.replace('Bearer ', '');
            if (token) {
                claims = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
            }
        }
        return claims;
    }
    ensureAdmin(claims) {
        const userRole = claims?.['custom:role'] || 'User';
        if (userRole !== 'Admin') {
            throw new common_1.HttpException('No autorizado: Requiere rol Admin', common_1.HttpStatus.FORBIDDEN);
        }
    }
    async getSalesReport(req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            const report = await this.reportsService.getSalesReport();
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Reporte de ventas obtenido exitosamente',
                data: report,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al generar reporte de ventas', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getSaleDetails(saleId, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            const details = await this.reportsService.getSaleDetails(saleId);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Detalles de venta obtenidos exitosamente',
                data: details,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al obtener detalles de venta', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getUsersReport(req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            const users = await this.reportsService.getUsersReport();
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Reporte de usuarios obtenido exitosamente',
                data: users,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al generar reporte de usuarios', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.ReportsController = ReportsController;
__decorate([
    (0, common_1.Get)('sales'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getSalesReport", null);
__decorate([
    (0, common_1.Get)('sales/:saleId'),
    __param(0, (0, common_1.Param)('saleId')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getSaleDetails", null);
__decorate([
    (0, common_1.Get)('users'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getUsersReport", null);
exports.ReportsController = ReportsController = __decorate([
    (0, common_1.Controller)('admin/reports'),
    __metadata("design:paramtypes", [reports_service_1.ReportsService])
], ReportsController);
//# sourceMappingURL=reports.controller.js.map