import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { ConfigService } from '@nestjs/config';
export declare class TicketsService {
    private readonly dynamoDbClient;
    private configService;
    private readonly tableName;
    private readonly scansTableName;
    private readonly docClient;
    private readonly s3Client;
    constructor(dynamoDbClient: DynamoDBClient, configService: ConfigService);
    createTickets(sale: {
        id: string;
        userId: string;
        eventId: string;
        batchId: string;
        quantity: number;
    }): Promise<{
        ticketId: string;
        saleId: string;
        qrS3Url: string;
    }[]>;
    validateTicket(ticketId: string): Promise<Record<string, any>>;
    scanTickets(ticketIds: string[]): Promise<{
        ticketId: string;
        status: "valid" | "invalid";
        message: string;
        ticket?: any;
    }[]>;
}
