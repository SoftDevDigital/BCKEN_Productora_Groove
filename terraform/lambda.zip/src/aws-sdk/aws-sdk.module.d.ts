export declare class AWSSDKModule {
}
