"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const cognito_service_1 = require("./cognito/cognito.service");
const signup_dto_1 = require("./dto/signup.dto");
const signin_dto_1 = require("./dto/signin.dto");
const confirm_dto_1 = require("./dto/confirm.dto");
const resend_dto_1 = require("./dto/resend.dto");
const admin_confirm_dto_1 = require("./dto/admin-confirm.dto");
const jwt = __importStar(require("jsonwebtoken"));
let AuthController = class AuthController {
    cognitoService;
    constructor(cognitoService) {
        this.cognitoService = cognitoService;
    }
    getClaims(req) {
        let claims = null;
        if (req['apiGateway']) {
            const ctx = req['apiGateway'].event.requestContext;
            claims = ctx.authorizer?.jwt?.claims || ctx.authorizer?.claims || null;
        }
        if (!claims) {
            const token = req.headers['authorization']?.replace('Bearer ', '');
            if (token) {
                claims = jwt.decode(token);
            }
        }
        return claims;
    }
    ensureAdmin(claims) {
        const userRole = claims?.['custom:role'] || 'User';
        if (userRole !== 'Admin') {
            throw new common_1.HttpException('No autorizado: Requiere rol Admin', common_1.HttpStatus.FORBIDDEN);
        }
    }
    async signUp(dto) {
        try {
            const result = await this.cognitoService.signUp(dto.name, dto.last_name, dto.email, dto.password);
            return {
                statusCode: common_1.HttpStatus.CREATED,
                message: 'Usuario registrado exitosamente. Verifica tu email para confirmar.',
                userSub: result.UserSub,
                codeDeliveryDetails: result.CodeDeliveryDetails,
            };
        }
        catch (error) {
            if (error.name === 'UsernameExistsException') {
                throw new common_1.HttpException('El email ya está registrado. Intenta con signin.', common_1.HttpStatus.CONFLICT);
            }
            if (error.name === 'InvalidParameterException' ||
                error.name === 'InvalidUserAttributeException') {
                throw new common_1.HttpException('Parámetros inválidos en el registro. Verifica el formato del email, password o rol.', common_1.HttpStatus.BAD_REQUEST);
            }
            throw new common_1.HttpException('Error al registrar usuario', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async signIn(dto) {
        try {
            const result = await this.cognitoService.signIn(dto.email, dto.password);
            if (result.$metadata.httpStatusCode !== 200) {
                throw result;
            }
            const { AuthenticationResult } = result;
            if (!AuthenticationResult) {
                throw new common_1.HttpException('Error en la autenticación: No se recibieron tokens', common_1.HttpStatus.UNAUTHORIZED);
            }
            const { IdToken, AccessToken, RefreshToken, ExpiresIn } = AuthenticationResult;
            if (!IdToken) {
                throw new common_1.HttpException('Error en la autenticación: IdToken no definido', common_1.HttpStatus.UNAUTHORIZED);
            }
            const payload = JSON.parse(Buffer.from(IdToken.split('.')[1], 'base64').toString());
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Login exitoso',
                accessToken: AccessToken,
                idToken: IdToken,
                refreshToken: RefreshToken,
                expiresIn: ExpiresIn,
                user: {
                    sub: payload.sub,
                    email: payload.email,
                    given_name: payload['given_name'],
                    family_name: payload['family_name'],
                    'custom:role': payload['custom:role'] || 'User',
                    'custom:country': payload['custom:country'],
                },
            };
        }
        catch (error) {
            if (error.name === 'NotAuthorizedException') {
                throw new common_1.HttpException('Email o contraseña incorrectos', common_1.HttpStatus.UNAUTHORIZED);
            }
            if (error.name === 'UserNotConfirmedException') {
                throw new common_1.HttpException('Usuario no confirmado. Verifica tu email primero.', common_1.HttpStatus.FORBIDDEN);
            }
            throw new common_1.HttpException('Error en el login', common_1.HttpStatus.UNAUTHORIZED);
        }
    }
    async assignRole(req, body) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            await this.cognitoService.adminAssignRole(body.userSub, body.role);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: `Rol "${body.role}" asignado exitosamente al usuario ${body.userSub}`,
            };
        }
        catch (error) {
            if (error instanceof common_1.BadRequestException) {
                throw new common_1.HttpException(error.message, common_1.HttpStatus.BAD_REQUEST);
            }
            throw new common_1.HttpException('Error al asignar rol', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async adminConfirm(req, dto) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            await this.cognitoService.adminConfirmSignUp(dto.username);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Usuario confirmado manualmente',
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error al confirmar usuario manualmente', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async confirm(dto) {
        try {
            await this.cognitoService.confirmSignUp(dto.username, dto.code);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Email confirmado exitosamente. Ahora puedes iniciar sesión.',
            };
        }
        catch (error) {
            if (error.name === 'CodeMismatchException') {
                throw new common_1.HttpException('Código de verificación incorrecto', common_1.HttpStatus.BAD_REQUEST);
            }
            if (error.name === 'ExpiredCodeException') {
                throw new common_1.HttpException('Código expirado. Solicita uno nuevo.', common_1.HttpStatus.BAD_REQUEST);
            }
            throw new common_1.HttpException('Error al confirmar email', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async resend(dto) {
        try {
            const result = await this.cognitoService.resendConfirmation(dto.email);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Código reenviado exitosamente. Revisa tu email.',
                codeDeliveryDetails: result.CodeDeliveryDetails,
            };
        }
        catch (error) {
            if (error.message === 'Debes esperar 1 minuto desde el último reenvío.') {
                throw new common_1.HttpException(error.message, common_1.HttpStatus.TOO_MANY_REQUESTS);
            }
            if (error.name === 'UserNotFoundException') {
                throw new common_1.HttpException('Usuario no encontrado. Regístrate primero.', common_1.HttpStatus.NOT_FOUND);
            }
            throw new common_1.HttpException('Error al reenviar código', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Post)('signup'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [signup_dto_1.SignUpDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "signUp", null);
__decorate([
    (0, common_1.Post)('signin'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [signin_dto_1.SignInDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "signIn", null);
__decorate([
    (0, common_1.Post)('admin/assign-role'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "assignRole", null);
__decorate([
    (0, common_1.Post)('admin/confirm-signup'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, admin_confirm_dto_1.AdminConfirmDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "adminConfirm", null);
__decorate([
    (0, common_1.Post)('confirm'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [confirm_dto_1.ConfirmDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "confirm", null);
__decorate([
    (0, common_1.Post)('resend-confirmation'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [resend_dto_1.ResendDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "resend", null);
exports.AuthController = AuthController = __decorate([
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [cognito_service_1.CognitoService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map