export declare class ResendDto {
    email: string;
}
