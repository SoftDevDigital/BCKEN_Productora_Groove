export declare class AdminConfirmDto {
    username: string;
}
