export declare class CreateDirectSaleDto {
    eventId: string;
    batchId: string;
    quantity: number;
    email: string;
}
