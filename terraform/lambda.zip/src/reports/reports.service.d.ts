import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { SalesService } from '../sales/sales.service';
import { TicketsService } from '../tickets/tickets.service';
import { UsersService } from '../users/users.service';
import { EventsService } from '../events/events.service';
import { BatchesService } from '../batches/batches.service';
import { User } from '../users/users/types';
export declare class ReportsService {
    private readonly dynamoDbClient;
    private readonly salesService;
    private readonly ticketsService;
    private readonly usersService;
    private readonly eventsService;
    private readonly batchesService;
    private readonly salesTable;
    private readonly docClient;
    constructor(dynamoDbClient: DynamoDBClient, salesService: SalesService, ticketsService: TicketsService, usersService: UsersService, eventsService: EventsService, batchesService: BatchesService);
    getSalesReport(): Promise<{
        totalSales: number;
        totalRevenue: any;
        ticketsSold: any;
        salesByType: {
            direct: number;
            reseller: number;
        };
        salesByEvent: {};
    }>;
    getSaleDetails(saleId: string): Promise<{
        sale: Record<string, any>;
        tickets: Record<string, any>[];
        buyer: {
            id: any;
            role: any;
            purchasedTickets: any;
        };
        reseller: {
            id: any;
            role: any;
            soldTickets: any;
        } | null;
        event: {
            id: any;
            name: any;
            from: any;
            to: any;
        };
        batch: {
            id: any;
            name: any;
        };
    }>;
    getUsersReport(): Promise<User[]>;
}
