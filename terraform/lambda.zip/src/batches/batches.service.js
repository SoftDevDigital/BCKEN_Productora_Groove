"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchesService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
let BatchesService = class BatchesService {
    dynamoDbClient;
    tableName = 'Batches-v2';
    docClient;
    constructor(dynamoDbClient) {
        this.dynamoDbClient = dynamoDbClient;
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDbClient);
    }
    async create(eventId, createBatchDto) {
        const batchId = (0, uuid_1.v4)();
        const params = {
            TableName: this.tableName,
            Item: {
                eventId,
                batchId,
                name: createBatchDto.name,
                totalTickets: createBatchDto.totalTickets,
                availableTickets: createBatchDto.totalTickets,
                price: createBatchDto.price,
                isVip: createBatchDto.isVip,
                startTime: createBatchDto.startTime,
                endTime: createBatchDto.endTime,
                createdAt: new Date().toISOString(),
            },
        };
        try {
            await this.docClient.send(new lib_dynamodb_1.PutCommand(params));
            return { batchId, ...createBatchDto };
        }
        catch (error) {
            throw new common_1.HttpException('Error al crear tanda en DynamoDB', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findAll(eventId) {
        const params = {
            TableName: this.tableName,
            KeyConditionExpression: 'eventId = :eventId',
            ExpressionAttributeValues: {
                ':eventId': eventId,
            },
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.QueryCommand(params));
            return result.Items || [];
        }
        catch (error) {
            throw new common_1.HttpException('Error al listar tandas', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findOne(eventId, batchId) {
        const params = {
            TableName: this.tableName,
            Key: { eventId, batchId },
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.GetCommand(params));
            return result.Item;
        }
        catch (error) {
            throw new common_1.HttpException('Error al obtener tanda', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async update(eventId, batchId, updateBatchDto) {
        const updateExpressionParts = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        const currentBatch = await this.findOne(eventId, batchId);
        if (!currentBatch) {
            throw new common_1.HttpException('Tanda no encontrada', common_1.HttpStatus.NOT_FOUND);
        }
        const ticketsSold = currentBatch.totalTickets - currentBatch.availableTickets;
        if (updateBatchDto.totalTickets !== undefined) {
            if (updateBatchDto.totalTickets < ticketsSold) {
                throw new common_1.HttpException(`No se puede reducir el total de tickets por debajo de los tickets vendidos (${ticketsSold})`, common_1.HttpStatus.BAD_REQUEST);
            }
            updateExpressionParts.push('#totalTickets = :totalTickets');
            updateExpressionParts.push('#availableTickets = :availableTickets');
            expressionAttributeNames['#totalTickets'] = 'totalTickets';
            expressionAttributeNames['#availableTickets'] = 'availableTickets';
            expressionAttributeValues[':totalTickets'] = updateBatchDto.totalTickets;
            expressionAttributeValues[':availableTickets'] =
                updateBatchDto.totalTickets - ticketsSold;
        }
        if (updateBatchDto.name !== undefined) {
            updateExpressionParts.push('#name = :name');
            expressionAttributeNames['#name'] = 'name';
            expressionAttributeValues[':name'] = updateBatchDto.name;
        }
        if (updateBatchDto.price !== undefined) {
            updateExpressionParts.push('#price = :price');
            expressionAttributeNames['#price'] = 'price';
            expressionAttributeValues[':price'] = updateBatchDto.price;
        }
        if (updateBatchDto.isVip !== undefined) {
            updateExpressionParts.push('#isVip = :isVip');
            expressionAttributeNames['#isVip'] = 'isVip';
            expressionAttributeValues[':isVip'] = updateBatchDto.isVip;
        }
        if (updateBatchDto.startTime !== undefined) {
            updateExpressionParts.push('#startTime = :startTime');
            expressionAttributeNames['#startTime'] = 'startTime';
            expressionAttributeValues[':startTime'] = updateBatchDto.startTime;
        }
        if (updateBatchDto.endTime !== undefined) {
            updateExpressionParts.push('#endTime = :endTime');
            expressionAttributeNames['#endTime'] = 'endTime';
            expressionAttributeValues[':endTime'] = updateBatchDto.endTime;
        }
        if (updateExpressionParts.length === 0) {
            throw new common_1.HttpException('No se proporcionaron datos para actualizar', common_1.HttpStatus.BAD_REQUEST);
        }
        const params = {
            TableName: this.tableName,
            Key: { eventId, batchId },
            UpdateExpression: 'SET ' + updateExpressionParts.join(', '),
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.UpdateCommand(params));
            return result.Attributes;
        }
        catch (error) {
            throw new common_1.HttpException('Error al actualizar tanda', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async remove(eventId, batchId) {
        const params = {
            TableName: this.tableName,
            Key: { eventId, batchId },
        };
        try {
            await this.docClient.send(new lib_dynamodb_1.DeleteCommand(params));
            return true;
        }
        catch (error) {
            throw new common_1.HttpException('Error al eliminar tanda', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async decrementTickets(eventId, batchId, quantity) {
        const params = {
            TableName: this.tableName,
            Key: { eventId, batchId },
            UpdateExpression: 'ADD #availableTickets :decrement',
            ExpressionAttributeNames: {
                '#availableTickets': 'availableTickets',
            },
            ExpressionAttributeValues: {
                ':decrement': -quantity,
                ':quantity': quantity,
            },
            ConditionExpression: '#availableTickets >= :quantity',
            ReturnValues: 'ALL_NEW',
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.UpdateCommand(params));
            return result.Attributes;
        }
        catch (error) {
            throw new common_1.HttpException('No hay tickets suficientes en la tanda o error al decrementar', common_1.HttpStatus.BAD_REQUEST);
        }
    }
};
exports.BatchesService = BatchesService;
exports.BatchesService = BatchesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)('DYNAMODB_CLIENT')),
    __metadata("design:paramtypes", [client_dynamodb_1.DynamoDBClient])
], BatchesService);
//# sourceMappingURL=batches.service.js.map