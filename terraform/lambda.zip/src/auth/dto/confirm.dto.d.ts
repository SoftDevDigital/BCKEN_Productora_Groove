export declare class ConfirmDto {
    username: string;
    code: string;
}
