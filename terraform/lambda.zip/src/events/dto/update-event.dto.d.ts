import { Multer } from 'multer';
export declare class UpdateEventDto {
    name?: string;
    from?: string;
    to?: string;
    location?: string;
    description?: string;
    image?: Multer.File;
}
