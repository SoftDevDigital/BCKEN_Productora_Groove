import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { CreateSaleDto } from './dto/create-sale.dto';
import { EventsService } from '../events/events.service';
import { BatchesService } from '../batches/batches.service';
import { TicketsService } from '../tickets/tickets.service';
import { UsersService } from '../users/users.service';
import { ConfigService } from '@nestjs/config';
import { PaymentsService } from '../payments/payments.service';
export declare class SalesService {
    private readonly dynamoDbClient;
    private readonly eventsService;
    private readonly batchesService;
    private readonly ticketsService;
    private readonly usersService;
    private readonly configService;
    private readonly paymentsService;
    private readonly tableName;
    private readonly docClient;
    private readonly sesClient;
    private readonly s3Client;
    constructor(dynamoDbClient: DynamoDBClient, eventsService: EventsService, batchesService: BatchesService, ticketsService: TicketsService, usersService: UsersService, configService: ConfigService, paymentsService: PaymentsService);
    createSale(createSaleDto: CreateSaleDto, userId: string, email: string, resellerId?: string, resellerEmail?: string): Promise<{
        id: string;
        eventId: string;
        batchId: string;
        quantity: number;
        type: "direct" | "reseller";
        basePrice: any;
        commission: number;
        total: number;
        status: string;
    }>;
    confirmSale(saleId: string, paymentStatus: string, paymentId: string): Promise<Record<string, any> | undefined>;
    handleWebhook(paymentId: string): Promise<{
        status: string;
        saleId: any;
        paymentStatus: any;
    }>;
}
