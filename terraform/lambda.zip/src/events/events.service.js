"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
const uuid_1 = require("uuid");
const config_1 = require("@nestjs/config");
let EventsService = class EventsService {
    dynamoDbClient;
    configService;
    tableName = 'Events-v2';
    batchesTableName = 'Batches-v2';
    docClient;
    s3Client;
    bucketName;
    constructor(dynamoDbClient, configService) {
        this.dynamoDbClient = dynamoDbClient;
        this.configService = configService;
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDbClient);
        this.s3Client = new client_s3_1.S3Client({
            region: this.configService.get('AWS_REGION') || 'us-east-1',
        });
        this.bucketName =
            this.configService.get('S3_BUCKET') || 'ticket-qr-bucket-dev-v2';
    }
    async create(createEventDto) {
        const eventId = (0, uuid_1.v4)();
        let imageUrl;
        if (createEventDto.image) {
            if (!createEventDto.image.buffer || !createEventDto.image.mimetype) {
                throw new common_1.HttpException('Archivo de imagen inválido', common_1.HttpStatus.BAD_REQUEST);
            }
            const fileExtension = createEventDto.image.mimetype.split('/')[1];
            if (!['png', 'jpeg', 'jpg'].includes(fileExtension)) {
                throw new common_1.HttpException('Solo se permiten imágenes PNG o JPEG', common_1.HttpStatus.BAD_REQUEST);
            }
            if (createEventDto.image.size > 5 * 1024 * 1024) {
                throw new common_1.HttpException('La imagen no debe exceder los 5MB', common_1.HttpStatus.BAD_REQUEST);
            }
            const imageKey = `events/event-${eventId}-${(0, uuid_1.v4)()}.${fileExtension}`;
            try {
                await this.s3Client.send(new client_s3_1.PutObjectCommand({
                    Bucket: this.bucketName,
                    Key: imageKey,
                    Body: createEventDto.image.buffer,
                    ContentType: createEventDto.image.mimetype,
                }));
                imageUrl = `https://${this.bucketName}.s3.amazonaws.com/${imageKey}`;
            }
            catch (error) {
                console.error('Error subiendo imagen a S3:', error);
                throw new common_1.HttpException(`Error al subir la imagen a S3: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        const params = {
            TableName: this.tableName,
            Item: {
                id: eventId,
                name: createEventDto.name,
                from: createEventDto.from,
                to: createEventDto.to,
                location: createEventDto.location,
                description: createEventDto.description,
                imageUrl,
                createdAt: new Date().toISOString(),
            },
        };
        try {
            await this.docClient.send(new lib_dynamodb_1.PutCommand(params));
            return { id: eventId, ...createEventDto, image: undefined, imageUrl };
        }
        catch (error) {
            console.error('Error creando evento en DynamoDB:', error);
            throw new common_1.HttpException('Error al crear evento en DynamoDB', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findAll() {
        const params = {
            TableName: this.tableName,
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.ScanCommand(params));
            return result.Items || [];
        }
        catch (error) {
            throw new common_1.HttpException('Error al obtener eventos', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async search(query) {
        const params = {
            TableName: this.tableName,
            FilterExpression: '',
            ExpressionAttributeNames: {},
            ExpressionAttributeValues: {},
        };
        const filterExpressions = [];
        const normalize = (str) => str ? str.trim().toLowerCase() : undefined;
        const normalizedQ = normalize(query.q);
        const normalizedName = normalize(query.name);
        const normalizedLocation = normalize(query.location);
        const normalizedDescription = normalize(query.description);
        const from = query.from;
        const to = query.to;
        if (normalizedQ) {
            filterExpressions.push('(contains(#nameLower, :q) OR contains(#locationLower, :q) OR contains(#descriptionLower, :q))');
            params.ExpressionAttributeNames['#nameLower'] = 'nameLower';
            params.ExpressionAttributeNames['#locationLower'] = 'locationLower';
            params.ExpressionAttributeNames['#descriptionLower'] =
                'descriptionLower';
            params.ExpressionAttributeValues[':q'] = normalizedQ;
        }
        if (normalizedName) {
            filterExpressions.push('contains(#nameLower, :name)');
            params.ExpressionAttributeNames['#nameLower'] = 'nameLower';
            params.ExpressionAttributeValues[':name'] = normalizedName;
        }
        if (normalizedLocation) {
            filterExpressions.push('contains(#locationLower, :location)');
            params.ExpressionAttributeNames['#locationLower'] = 'locationLower';
            params.ExpressionAttributeValues[':location'] = normalizedLocation;
        }
        if (normalizedDescription) {
            filterExpressions.push('contains(#descriptionLower, :description)');
            params.ExpressionAttributeNames['#descriptionLower'] =
                'descriptionLower';
            params.ExpressionAttributeValues[':description'] = normalizedDescription;
        }
        if (from) {
            filterExpressions.push('#from >= :from');
            params.ExpressionAttributeNames['#from'] = 'from';
            params.ExpressionAttributeValues[':from'] = from;
        }
        if (to) {
            filterExpressions.push('#to <= :to');
            params.ExpressionAttributeNames['#to'] = 'to';
            params.ExpressionAttributeValues[':to'] = to;
        }
        if (filterExpressions.length > 0) {
            params.FilterExpression = filterExpressions.join(' AND ');
        }
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.ScanCommand(params));
            return result.Items || [];
        }
        catch (error) {
            throw new common_1.HttpException('Error al buscar eventos', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findOne(id) {
        const params = {
            TableName: this.tableName,
            Key: { id },
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.GetCommand(params));
            return result.Item || null;
        }
        catch (error) {
            throw new common_1.HttpException('Error al obtener evento', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async update(id, updateEventDto) {
        const updateExpressionParts = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        if (updateEventDto.image) {
            if (!updateEventDto.image.buffer || !updateEventDto.image.mimetype) {
                throw new common_1.HttpException('Archivo de imagen inválido', common_1.HttpStatus.BAD_REQUEST);
            }
            const fileExtension = updateEventDto.image.mimetype.split('/')[1];
            if (!['png', 'jpeg', 'jpg'].includes(fileExtension)) {
                throw new common_1.HttpException('Solo se permiten imágenes PNG o JPEG', common_1.HttpStatus.BAD_REQUEST);
            }
            if (updateEventDto.image.size > 5 * 1024 * 1024) {
                throw new common_1.HttpException('La imagen no debe exceder los 5MB', common_1.HttpStatus.BAD_REQUEST);
            }
            const imageKey = `events/event-${id}-${(0, uuid_1.v4)()}.${fileExtension}`;
            try {
                await this.s3Client.send(new client_s3_1.PutObjectCommand({
                    Bucket: this.bucketName,
                    Key: imageKey,
                    Body: updateEventDto.image.buffer,
                    ContentType: updateEventDto.image.mimetype,
                }));
                const imageUrl = `https://${this.bucketName}.s3.amazonaws.com/${imageKey}`;
                updateExpressionParts.push('#imageUrl = :imageUrl');
                expressionAttributeNames['#imageUrl'] = 'imageUrl';
                expressionAttributeValues[':imageUrl'] = imageUrl;
            }
            catch (error) {
                console.error('Error subiendo imagen a S3:', error);
                throw new common_1.HttpException(`Error al subir la imagen a S3: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        if (updateEventDto.name) {
            updateExpressionParts.push('#name = :name');
            expressionAttributeNames['#name'] = 'name';
            expressionAttributeValues[':name'] = updateEventDto.name;
        }
        if (updateEventDto.from) {
            updateExpressionParts.push('#from = :from');
            expressionAttributeNames['#from'] = 'from';
            expressionAttributeValues[':from'] = updateEventDto.from;
        }
        if (updateEventDto.to) {
            updateExpressionParts.push('#to = :to');
            expressionAttributeNames['#to'] = 'to';
            expressionAttributeValues[':to'] = updateEventDto.to;
        }
        if (updateEventDto.location) {
            updateExpressionParts.push('#location = :location');
            expressionAttributeNames['#location'] = 'location';
            expressionAttributeValues[':location'] = updateEventDto.location;
        }
        if (updateEventDto.description !== undefined) {
            updateExpressionParts.push('#description = :description');
            expressionAttributeNames['#description'] = 'description';
            expressionAttributeValues[':description'] = updateEventDto.description;
        }
        if (updateExpressionParts.length === 0) {
            throw new common_1.HttpException('No se proporcionaron datos para actualizar', common_1.HttpStatus.BAD_REQUEST);
        }
        updateExpressionParts.push('#updatedAt = :updatedAt');
        expressionAttributeNames['#updatedAt'] = 'updatedAt';
        expressionAttributeValues[':updatedAt'] = new Date().toISOString();
        const params = {
            TableName: this.tableName,
            Key: { id },
            UpdateExpression: 'SET ' + updateExpressionParts.join(', '),
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.UpdateCommand(params));
            return { ...result.Attributes, image: undefined };
        }
        catch (error) {
            console.error('Error actualizando evento en DynamoDB:', error);
            throw new common_1.HttpException('Error al actualizar evento en DynamoDB', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async delete(id) {
        const batchParams = {
            TableName: this.batchesTableName,
            KeyConditionExpression: 'eventId = :eventId',
            ExpressionAttributeValues: {
                ':eventId': id,
            },
        };
        try {
            const batchResult = await this.docClient.send(new lib_dynamodb_1.QueryCommand(batchParams));
            const batches = batchResult.Items || [];
            for (const batch of batches) {
                const deleteBatchParams = {
                    TableName: this.batchesTableName,
                    Key: { eventId: id, batchId: batch.batchId },
                };
                await this.docClient.send(new lib_dynamodb_1.DeleteCommand(deleteBatchParams));
            }
            const eventParams = {
                TableName: this.tableName,
                Key: { id },
            };
            await this.docClient.send(new lib_dynamodb_1.DeleteCommand(eventParams));
            return { message: `Evento ${id} y sus tandas asociadas eliminados` };
        }
        catch (error) {
            throw new common_1.HttpException('Error al eliminar evento y sus tandas', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.EventsService = EventsService;
exports.EventsService = EventsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)('DYNAMODB_CLIENT')),
    __metadata("design:paramtypes", [client_dynamodb_1.DynamoDBClient,
        config_1.ConfigService])
], EventsService);
//# sourceMappingURL=events.service.js.map