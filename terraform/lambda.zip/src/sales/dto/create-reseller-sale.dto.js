"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateResellerSaleDto = void 0;
class CreateResellerSaleDto {
    eventId;
    batchId;
    quantity;
    buyerInfo;
}
exports.CreateResellerSaleDto = CreateResellerSaleDto;
//# sourceMappingURL=create-reseller-sale.dto.js.map