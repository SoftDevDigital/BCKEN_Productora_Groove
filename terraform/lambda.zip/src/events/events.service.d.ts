import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';
import { SearchEventDto } from './dto/search.dto';
import { ConfigService } from '@nestjs/config';
export declare class EventsService {
    private readonly dynamoDbClient;
    private readonly configService;
    private readonly tableName;
    private readonly batchesTableName;
    private readonly docClient;
    private readonly s3Client;
    private readonly bucketName;
    constructor(dynamoDbClient: DynamoDBClient, configService: ConfigService);
    create(createEventDto: CreateEventDto): Promise<{
        image: undefined;
        imageUrl: string | undefined;
        name: string;
        from: string;
        to: string;
        location: string;
        description?: string;
        id: string;
    }>;
    findAll(): Promise<Record<string, any>[]>;
    search(query: SearchEventDto): Promise<Record<string, any>[]>;
    findOne(id: string): Promise<Record<string, any> | null>;
    update(id: string, updateEventDto: UpdateEventDto): Promise<{
        image: undefined;
    }>;
    delete(id: string): Promise<{
        message: string;
    }>;
}
