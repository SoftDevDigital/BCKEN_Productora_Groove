import { ConfigService } from '@nestjs/config';
import { MercadoPagoConfig } from 'mercadopago';
import { CreateQrDto } from './dto/create-qr.dto';
export declare class PaymentsService {
    private configService;
    client: MercadoPagoConfig;
    constructor(configService: ConfigService);
    generateQr(dto: CreateQrDto, saleId: string): Promise<any>;
    getPaymentStatus(paymentId: string): Promise<any>;
}
