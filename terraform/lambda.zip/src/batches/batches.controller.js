"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchesController = void 0;
const common_1 = require("@nestjs/common");
const batches_service_1 = require("./batches.service");
const create_batc_dto_1 = require("./dto/create-batc.dto");
const update_batch_dto_1 = require("./dto/update-batch.dto");
let BatchesController = class BatchesController {
    batchesService;
    constructor(batchesService) {
        this.batchesService = batchesService;
    }
    getClaims(req) {
        let claims = null;
        if (req['apiGateway']) {
            const ctx = req['apiGateway'].event.requestContext;
            claims = ctx.authorizer?.jwt?.claims || ctx.authorizer?.claims || null;
        }
        if (!claims) {
            const token = req.headers['authorization']?.replace('Bearer ', '');
            if (token) {
                claims = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
            }
        }
        return claims;
    }
    ensureAdmin(claims) {
        const userRole = claims?.['custom:role'] || 'User';
        if (userRole !== 'Admin') {
            throw new common_1.HttpException('No autorizado: Requiere rol Admin', common_1.HttpStatus.FORBIDDEN);
        }
    }
    async create(eventId, dto, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            if (new Date(dto.startTime) >= new Date(dto.endTime)) {
                throw new common_1.HttpException('El horario de inicio debe ser anterior al horario de finalización', common_1.HttpStatus.BAD_REQUEST);
            }
            const result = await this.batchesService.create(eventId, dto);
            return {
                statusCode: common_1.HttpStatus.CREATED,
                message: `Tanda ${dto.isVip ? 'VIP' : 'general'} creada exitosamente`,
                data: result,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al crear tanda', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findAll(eventId) {
        try {
            const batches = await this.batchesService.findAll(eventId);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Tandas obtenidas exitosamente',
                data: batches,
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error al obtener tandas', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async update(eventId, batchId, dto, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            if (dto.startTime &&
                dto.endTime &&
                new Date(dto.startTime) >= new Date(dto.endTime)) {
                throw new common_1.HttpException('El horario de inicio debe ser anterior al horario de finalización', common_1.HttpStatus.BAD_REQUEST);
            }
            const updatedBatch = await this.batchesService.update(eventId, batchId, dto);
            if (!updatedBatch) {
                throw new common_1.HttpException('Tanda no encontrada', common_1.HttpStatus.NOT_FOUND);
            }
            return {
                statusCode: common_1.HttpStatus.OK,
                message: `Tanda ${dto.isVip !== undefined ? (dto.isVip ? 'VIP' : 'general') : ''} actualizada exitosamente`,
                data: updatedBatch,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al actualizar tanda', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async remove(eventId, batchId, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            const result = await this.batchesService.remove(eventId, batchId);
            if (!result) {
                throw new common_1.HttpException('Tanda no encontrada', common_1.HttpStatus.NOT_FOUND);
            }
            return {
                statusCode: common_1.HttpStatus.OK,
                message: `Tanda ${batchId} eliminada`,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al eliminar tanda', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.BatchesController = BatchesController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Param)('eventId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_batc_dto_1.CreateBatchDto, Object]),
    __metadata("design:returntype", Promise)
], BatchesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Param)('eventId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BatchesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Put)(':batchId'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Param)('eventId')),
    __param(1, (0, common_1.Param)('batchId')),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, update_batch_dto_1.UpdateBatchDto, Object]),
    __metadata("design:returntype", Promise)
], BatchesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':batchId'),
    __param(0, (0, common_1.Param)('eventId')),
    __param(1, (0, common_1.Param)('batchId')),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], BatchesController.prototype, "remove", null);
exports.BatchesController = BatchesController = __decorate([
    (0, common_1.Controller)('events/:eventId/batches'),
    __metadata("design:paramtypes", [batches_service_1.BatchesService])
], BatchesController);
//# sourceMappingURL=batches.controller.js.map