export declare class SearchEventDto {
    q?: string;
    name?: string;
    location?: string;
    description?: string;
    from?: string;
    to?: string;
}
