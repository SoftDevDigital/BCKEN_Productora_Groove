"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketsService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const nanoid_1 = require("nanoid");
const QRCode = __importStar(require("qrcode"));
const client_s3_1 = require("@aws-sdk/client-s3");
const config_1 = require("@nestjs/config");
const uuid_1 = require("uuid");
let TicketsService = class TicketsService {
    dynamoDbClient;
    configService;
    tableName = 'Tickets-v2';
    scansTableName = 'TicketScans-v2';
    docClient;
    s3Client;
    constructor(dynamoDbClient, configService) {
        this.dynamoDbClient = dynamoDbClient;
        this.configService = configService;
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDbClient);
        this.s3Client = new client_s3_1.S3Client({
            region: this.configService.get('AWS_REGION'),
        });
    }
    async createTickets(sale) {
        const tickets = [];
        const bucket = this.configService.get('S3_BUCKET') || 'ticket-qr-bucket-dev-v2';
        for (let i = 0; i < sale.quantity; i++) {
            const ticketId = (0, nanoid_1.nanoid)(6);
            const qrData = `ticketId:${ticketId}`;
            const qrImageBuffer = await QRCode.toBuffer(qrData, { type: 'png' });
            const qrKey = `qrs/ticket-${ticketId}-${(0, uuid_1.v4)()}.png`;
            await this.s3Client.send(new client_s3_1.PutObjectCommand({
                Bucket: bucket,
                Key: qrKey,
                Body: qrImageBuffer,
                ContentType: 'image/png',
            }));
            const qrS3Url = `https://${bucket}.s3.amazonaws.com/${qrKey}`;
            const params = {
                TableName: this.tableName,
                Item: {
                    id: ticketId,
                    saleId: sale.id,
                    userId: sale.userId,
                    eventId: sale.eventId,
                    batchId: sale.batchId,
                    status: 'active',
                    qrS3Url,
                    createdAt: new Date().toISOString(),
                },
            };
            await this.docClient.send(new lib_dynamodb_1.PutCommand(params));
            tickets.push({ ticketId, saleId: sale.id, qrS3Url });
        }
        return tickets;
    }
    async validateTicket(ticketId) {
        const params = {
            TableName: this.tableName,
            Key: { id: ticketId },
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.GetCommand(params));
            if (!result.Item || result.Item.status !== 'active') {
                throw new common_1.HttpException('Ticket no válido o inactivo', common_1.HttpStatus.BAD_REQUEST);
            }
            return result.Item;
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al validar ticket', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async scanTickets(ticketIds) {
        const results = [];
        const scanRecords = [];
        for (const ticketId of ticketIds) {
            try {
                const ticket = await this.validateTicket(ticketId);
                await this.docClient.send(new lib_dynamodb_1.UpdateCommand({
                    TableName: this.tableName,
                    Key: { id: ticketId },
                    UpdateExpression: 'SET #status = :status, #usedAt = :usedAt',
                    ExpressionAttributeNames: {
                        '#status': 'status',
                        '#usedAt': 'usedAt',
                    },
                    ExpressionAttributeValues: {
                        ':status': 'used',
                        ':usedAt': new Date().toISOString(),
                    },
                }));
                const scanId = (0, nanoid_1.nanoid)(10);
                scanRecords.push({
                    id: scanId,
                    ticketId,
                    status: 'valid',
                    scannedAt: new Date().toISOString(),
                });
                results.push({
                    ticketId,
                    status: 'valid',
                    message: 'Ticket válido y marcado como usado',
                    ticket: {
                        ticketId: ticket.id,
                        saleId: ticket.saleId,
                        userId: ticket.userId,
                        eventId: ticket.eventId,
                        batchId: ticket.batchId,
                        status: 'used',
                        qrS3Url: ticket.qrS3Url,
                    },
                });
            }
            catch (error) {
                const scanId = (0, nanoid_1.nanoid)(10);
                scanRecords.push({
                    id: scanId,
                    ticketId,
                    status: 'invalid',
                    scannedAt: new Date().toISOString(),
                });
                results.push({
                    ticketId,
                    status: 'invalid',
                    message: error.message || 'Ticket no válido o inactivo',
                });
            }
        }
        for (const scan of scanRecords) {
            await this.docClient.send(new lib_dynamodb_1.PutCommand({
                TableName: this.scansTableName,
                Item: scan,
            }));
        }
        return results;
    }
};
exports.TicketsService = TicketsService;
exports.TicketsService = TicketsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)('DYNAMODB_CLIENT')),
    __metadata("design:paramtypes", [client_dynamodb_1.DynamoDBClient,
        config_1.ConfigService])
], TicketsService);
//# sourceMappingURL=tickets.service.js.map