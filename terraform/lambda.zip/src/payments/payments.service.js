"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const mercadopago_1 = require("mercadopago");
let PaymentsService = class PaymentsService {
    configService;
    client;
    constructor(configService) {
        this.configService = configService;
        const accessToken = 'APP_USR-8581189409054279-091018-c6d03928f1a9466fb3fbc1cdbcf80512-2369426390';
        if (!accessToken) {
            throw new common_1.BadRequestException('MERCADO_PAGO_ACCESS_TOKEN is not defined in environment variables');
        }
        console.log('MercadoPago Access Token:', accessToken);
        this.client = new mercadopago_1.MercadoPagoConfig({
            accessToken,
            options: { timeout: 5000 },
        });
    }
    async generateQr(dto, saleId) {
        const preference = new mercadopago_1.Preference(this.client);
        const apiBaseUrl = this.configService.get('API_BASE_URL');
        if (!apiBaseUrl) {
            throw new common_1.BadRequestException('API_BASE_URL is not defined in environment variables');
        }
        const preferenceData = {
            items: [
                {
                    id: `sale-${saleId}`,
                    title: dto.title,
                    unit_price: dto.amount,
                    quantity: 1,
                    currency_id: 'ARS',
                },
            ],
            payment_methods: {
                excluded_payment_methods: [],
                excluded_payment_types: [],
                installments: 1,
            },
            back_urls: {
                success: `https://df2c6b52db81.ngrok-free.app/payments/success?saleId=${saleId}`,
                failure: `https://df2c6b52db81.ngrok-free.app/payments/failure?saleId=${saleId}`,
                pending: `https://df2c6b52db81.ngrok-free.app/payments/pending?saleId=${saleId}`,
            },
            auto_return: 'approved',
            external_reference: saleId,
            notification_url: `https://df2c6b52db81.ngrok-free.app/sales/webhook`,
        };
        try {
            const response = await preference.create({ body: preferenceData });
            console.log('Preference created:', response.id);
            return {
                paymentLink: response.init_point,
                preferenceId: response.id,
                saleId,
            };
        }
        catch (error) {
            console.error('Error generating preference:', error);
            throw new common_1.BadRequestException(`Error al generar link de pago: ${error.message}`);
        }
    }
    async getPaymentStatus(paymentId) {
        const payment = new mercadopago_1.Payment(this.client);
        try {
            const response = await payment.get({ id: paymentId });
            console.log('Payment status retrieved:', {
                id: paymentId,
                status: response.status,
            });
            return response;
        }
        catch (error) {
            console.error('Error retrieving payment status:', error);
            throw new common_1.BadRequestException(`Error al verificar pago: ${error.message}`);
        }
    }
};
exports.PaymentsService = PaymentsService;
exports.PaymentsService = PaymentsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], PaymentsService);
//# sourceMappingURL=payments.service.js.map