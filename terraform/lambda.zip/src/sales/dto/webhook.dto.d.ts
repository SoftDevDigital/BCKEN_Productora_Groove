export declare class WebhookDto {
    saleId: string;
    paymentStatus: 'approved' | 'rejected' | 'pending';
    paymentId: string;
}
