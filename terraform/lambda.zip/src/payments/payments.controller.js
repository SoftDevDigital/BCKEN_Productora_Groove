"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsController = void 0;
const common_1 = require("@nestjs/common");
const payments_service_1 = require("./payments.service");
const sales_service_1 = require("../sales/sales.service");
const config_1 = require("@nestjs/config");
let PaymentsController = class PaymentsController {
    paymentsService;
    salesService;
    configService;
    constructor(paymentsService, salesService, configService) {
        this.paymentsService = paymentsService;
        this.salesService = salesService;
        this.configService = configService;
    }
    async handleSuccess(saleId, paymentId, res) {
        console.log('ENTROOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO');
        console.log('handleSuccess called:', { saleId, paymentId });
        try {
            if (!saleId || !paymentId) {
                throw new common_1.HttpException('Faltan parámetros saleId o collection_id', common_1.HttpStatus.BAD_REQUEST);
            }
            const payment = await this.paymentsService.getPaymentStatus(paymentId);
            console.log('Payment status:', payment);
            if (payment.status !== 'approved' ||
                payment.external_reference !== saleId) {
                throw new common_1.HttpException('Pago no aprobado o mismatch en saleId', common_1.HttpStatus.BAD_REQUEST);
            }
            await this.salesService.confirmSale(saleId, 'approved', paymentId);
            const frontendUrl = this.configService.get('FRONTEND_BASE_URL');
            if (!frontendUrl) {
                throw new common_1.HttpException('FRONTEND_BASE_URL is not defined in environment variables', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
            }
            res.redirect(302, `${frontendUrl}/success?saleId=${saleId}`);
        }
        catch (error) {
            console.error('Error en handleSuccess:', error);
            const frontendUrl = this.configService.get('FRONTEND_BASE_URL') ||
                'https://tu-frontend.com';
            res.redirect(302, `${frontendUrl}/failure?saleId=${saleId}&error=${encodeURIComponent(error.message)}`);
        }
    }
    async handleFailure(saleId, paymentId, res) {
        try {
            if (!saleId || !paymentId) {
                throw new common_1.HttpException('Faltan parámetros saleId o collection_id', common_1.HttpStatus.BAD_REQUEST);
            }
            const payment = await this.paymentsService.getPaymentStatus(paymentId);
            await this.salesService.confirmSale(saleId, 'rejected', paymentId);
            const frontendUrl = this.configService.get('FRONTEND_BASE_URL');
            if (!frontendUrl) {
                throw new common_1.HttpException('FRONTEND_BASE_URL is not defined in environment variables', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
            }
            res.redirect(302, `${frontendUrl}/failure?saleId=${saleId}`);
        }
        catch (error) {
            console.error('Error en handleFailure:', error);
            const frontendUrl = this.configService.get('FRONTEND_BASE_URL') ||
                'https://tu-frontend.com';
            res.redirect(302, `${frontendUrl}/failure?saleId=${saleId}&error=${encodeURIComponent(error.message)}`);
        }
    }
    async handlePending(saleId, paymentId, res) {
        try {
            if (!saleId || !paymentId) {
                throw new common_1.HttpException('Faltan parámetros saleId o collection_id', common_1.HttpStatus.BAD_REQUEST);
            }
            const payment = await this.paymentsService.getPaymentStatus(paymentId);
            console.log('Payment status:', payment);
            await this.salesService.confirmSale(saleId, 'pending', paymentId);
            const frontendUrl = this.configService.get('FRONTEND_BASE_URL');
            if (!frontendUrl) {
                throw new common_1.HttpException('FRONTEND_BASE_URL is not defined in environment variables', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
            }
            res.redirect(302, `${frontendUrl}/pending?saleId=${saleId}`);
        }
        catch (error) {
            console.error('Error en handlePending:', error);
            const frontendUrl = this.configService.get('FRONTEND_BASE_URL') ||
                'https://tu-frontend.com';
            res.redirect(302, `${frontendUrl}/failure?saleId=${saleId}&error=${encodeURIComponent(error.message)}`);
        }
    }
};
exports.PaymentsController = PaymentsController;
__decorate([
    (0, common_1.Get)('success'),
    __param(0, (0, common_1.Query)('saleId')),
    __param(1, (0, common_1.Query)('collection_id')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "handleSuccess", null);
__decorate([
    (0, common_1.Get)('failure'),
    __param(0, (0, common_1.Query)('saleId')),
    __param(1, (0, common_1.Query)('collection_id')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "handleFailure", null);
__decorate([
    (0, common_1.Get)('pending'),
    __param(0, (0, common_1.Query)('saleId')),
    __param(1, (0, common_1.Query)('collection_id')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "handlePending", null);
exports.PaymentsController = PaymentsController = __decorate([
    (0, common_1.Controller)('payments'),
    __metadata("design:paramtypes", [payments_service_1.PaymentsService,
        sales_service_1.SalesService,
        config_1.ConfigService])
], PaymentsController);
//# sourceMappingURL=payments.controller.js.map