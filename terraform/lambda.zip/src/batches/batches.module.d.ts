export declare class BatchesModule {
}
