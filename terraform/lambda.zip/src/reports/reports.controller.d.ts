import { HttpStatus } from '@nestjs/common';
import { ReportsService } from './reports.service';
import type { Request } from 'express';
import { User } from '../users/users/types';
export declare class ReportsController {
    private readonly reportsService;
    constructor(reportsService: ReportsService);
    private getClaims;
    private ensureAdmin;
    getSalesReport(req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            totalSales: number;
            totalRevenue: any;
            ticketsSold: any;
            salesByType: {
                direct: number;
                reseller: number;
            };
            salesByEvent: {};
        };
    }>;
    getSaleDetails(saleId: string, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            sale: Record<string, any>;
            tickets: Record<string, any>[];
            buyer: {
                id: any;
                role: any;
                purchasedTickets: any;
            };
            reseller: {
                id: any;
                role: any;
                soldTickets: any;
            } | null;
            event: {
                id: any;
                name: any;
                from: any;
                to: any;
            };
            batch: {
                id: any;
                name: any;
            };
        };
    }>;
    getUsersReport(req: Request): Promise<{
        statusCode: number;
        message: string;
        data: User[];
    }>;
}
