import { HttpStatus } from '@nestjs/common';
import { CognitoService } from './cognito/cognito.service';
import { SignUpDto } from './dto/signup.dto';
import { SignInDto } from './dto/signin.dto';
import { ConfirmDto } from './dto/confirm.dto';
import { ResendDto } from './dto/resend.dto';
import { AdminConfirmDto } from './dto/admin-confirm.dto';
import type { Request } from 'express';
export declare class AuthController {
    private cognitoService;
    constructor(cognitoService: CognitoService);
    private getClaims;
    private ensureAdmin;
    signUp(dto: SignUpDto): Promise<{
        statusCode: HttpStatus;
        message: string;
        userSub: string | undefined;
        codeDeliveryDetails: import("@aws-sdk/client-cognito-identity-provider").CodeDeliveryDetailsType | undefined;
    }>;
    signIn(dto: SignInDto): Promise<{
        statusCode: HttpStatus;
        message: string;
        accessToken: string | undefined;
        idToken: string;
        refreshToken: string | undefined;
        expiresIn: number | undefined;
        user: {
            sub: string;
            email: string;
            given_name: string;
            family_name: string;
            'custom:role': any;
            'custom:country': any;
        };
    }>;
    assignRole(req: Request, body: {
        userSub: string;
        role: string;
    }): Promise<{
        statusCode: HttpStatus;
        message: string;
    }>;
    adminConfirm(req: Request, dto: AdminConfirmDto): Promise<{
        statusCode: HttpStatus;
        message: string;
    }>;
    confirm(dto: ConfirmDto): Promise<{
        statusCode: HttpStatus;
        message: string;
    }>;
    resend(dto: ResendDto): Promise<{
        statusCode: HttpStatus;
        message: string;
        codeDeliveryDetails: import("@aws-sdk/client-cognito-identity-provider").CodeDeliveryDetailsType | undefined;
    }>;
}
