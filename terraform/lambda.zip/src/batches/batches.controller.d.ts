import { HttpStatus } from '@nestjs/common';
import { BatchesService } from './batches.service';
import { CreateBatchDto } from './dto/create-batc.dto';
import { UpdateBatchDto } from './dto/update-batch.dto';
import type { Request } from 'express';
export declare class BatchesController {
    private readonly batchesService;
    constructor(batchesService: BatchesService);
    private getClaims;
    private ensureAdmin;
    create(eventId: string, dto: CreateBatchDto, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            name: string;
            totalTickets: number;
            price: number;
            isVip: boolean;
            startTime: string;
            endTime: string;
            batchId: string;
        };
    }>;
    findAll(eventId: string): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: Record<string, any>[];
    }>;
    update(eventId: string, batchId: string, dto: UpdateBatchDto, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: Record<string, any>;
    }>;
    remove(eventId: string, batchId: string, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
    }>;
}
