"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesController = void 0;
const common_1 = require("@nestjs/common");
const sales_service_1 = require("./sales.service");
const payments_service_1 = require("../payments/payments.service");
const batches_service_1 = require("../batches/batches.service");
const create_sale_dto_1 = require("./dto/create-sale.dto");
let SalesController = class SalesController {
    salesService;
    paymentsService;
    batchesService;
    constructor(salesService, paymentsService, batchesService) {
        this.salesService = salesService;
        this.paymentsService = paymentsService;
        this.batchesService = batchesService;
    }
    getClaims(req) {
        let claims = null;
        if (req['apiGateway']) {
            const ctx = req['apiGateway'].event.requestContext;
            claims = ctx.authorizer?.jwt?.claims || ctx.authorizer?.claims || null;
        }
        if (!claims) {
            const token = req.headers['authorization']?.replace('Bearer ', '');
            if (token) {
                claims = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
            }
        }
        return claims;
    }
    ensureAuthenticated(claims) {
        if (!claims || !claims['sub']) {
            throw new common_1.HttpException('No autorizado', common_1.HttpStatus.UNAUTHORIZED);
        }
    }
    ensureReseller(claims) {
        const userRole = claims?.['custom:role'] || 'User';
        if (userRole !== 'Reseller') {
            throw new common_1.HttpException('No autorizado: Requiere rol Reseller', common_1.HttpStatus.FORBIDDEN);
        }
    }
    async createDirect(dto, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAuthenticated(claims);
            if (dto.type !== 'direct') {
                throw new common_1.HttpException('Use /sales/reseller para ventas por revendedor', common_1.HttpStatus.BAD_REQUEST);
            }
            const sale = await this.salesService.createSale(dto, claims['sub'], claims['email']);
            const batch = await this.batchesService.findOne(dto.eventId, dto.batchId);
            const qr = await this.paymentsService.generateQr({
                title: `Compra de ${dto.quantity} ticket(s) para evento ${dto.eventId}`,
                amount: sale.total,
                saleId: sale.id,
            }, sale.id);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Venta registrada como pendiente. Complete el pago.',
                data: { ...sale, paymentLink: qr.paymentLink },
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al procesar la compra', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async createReseller(dto, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureReseller(claims);
            if (dto.type !== 'reseller') {
                throw new common_1.HttpException('Use /sales para ventas directas', common_1.HttpStatus.BAD_REQUEST);
            }
            const sale = await this.salesService.createSale(dto, claims['sub'], claims['email'], claims['sub'], claims['email']);
            const batch = await this.batchesService.findOne(dto.eventId, dto.batchId);
            const qr = await this.paymentsService.generateQr({
                title: `Compra de ${dto.quantity} ticket(s) para evento ${dto.eventId} (Revendedor)`,
                amount: sale.total,
                saleId: sale.id,
            }, sale.id);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Venta por revendedor registrada como pendiente. Complete el pago.',
                data: { ...sale, paymentLink: qr.paymentLink },
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al procesar la compra por revendedor', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async handleWebhook(body) {
        try {
            if (body.action === 'payment.updated') {
                const paymentId = body.data.id;
                await this.salesService.handleWebhook(paymentId);
            }
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Notificación recibida',
            };
        }
        catch (error) {
            console.error('Error en webhook:', error);
            throw new common_1.HttpException('Error al procesar webhook', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.SalesController = SalesController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_sale_dto_1.CreateSaleDto, Object]),
    __metadata("design:returntype", Promise)
], SalesController.prototype, "createDirect", null);
__decorate([
    (0, common_1.Post)('reseller'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_sale_dto_1.CreateSaleDto, Object]),
    __metadata("design:returntype", Promise)
], SalesController.prototype, "createReseller", null);
__decorate([
    (0, common_1.Post)('webhook'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SalesController.prototype, "handleWebhook", null);
exports.SalesController = SalesController = __decorate([
    (0, common_1.Controller)('sales'),
    __metadata("design:paramtypes", [sales_service_1.SalesService,
        payments_service_1.PaymentsService,
        batches_service_1.BatchesService])
], SalesController);
//# sourceMappingURL=sales.controller.js.map