import { ConfigService } from '@nestjs/config';
export declare class CognitoService {
    private configService;
    private client;
    private lastResend;
    private readonly validRoles;
    constructor(configService: ConfigService);
    private getSecretHash;
    signUp(name: string, last_name: string, email: string, password: string): Promise<{
        UserSub: string | undefined;
        CodeDeliveryDetails: import("@aws-sdk/client-cognito-identity-provider").CodeDeliveryDetailsType | undefined;
    }>;
    signIn(email: string, password: string): Promise<import("@aws-sdk/client-cognito-identity-provider").InitiateAuthCommandOutput>;
    adminAssignRole(userSub: string, role: string): Promise<import("@aws-sdk/client-cognito-identity-provider").AdminUpdateUserAttributesCommandOutput>;
    confirmSignUp(email: string, confirmationCode: string): Promise<import("@aws-sdk/client-cognito-identity-provider").ConfirmSignUpCommandOutput>;
    resendConfirmation(email: string): Promise<import("@aws-sdk/client-cognito-identity-provider").ResendConfirmationCodeCommandOutput>;
    adminConfirmSignUp(username: string): Promise<import("@aws-sdk/client-cognito-identity-provider").AdminConfirmSignUpCommandOutput>;
}
