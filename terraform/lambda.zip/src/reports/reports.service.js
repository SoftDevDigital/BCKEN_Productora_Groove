"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const sales_service_1 = require("../sales/sales.service");
const tickets_service_1 = require("../tickets/tickets.service");
const users_service_1 = require("../users/users.service");
const events_service_1 = require("../events/events.service");
const batches_service_1 = require("../batches/batches.service");
let ReportsService = class ReportsService {
    dynamoDbClient;
    salesService;
    ticketsService;
    usersService;
    eventsService;
    batchesService;
    salesTable = 'Sales-v2';
    docClient;
    constructor(dynamoDbClient, salesService, ticketsService, usersService, eventsService, batchesService) {
        this.dynamoDbClient = dynamoDbClient;
        this.salesService = salesService;
        this.ticketsService = ticketsService;
        this.usersService = usersService;
        this.eventsService = eventsService;
        this.batchesService = batchesService;
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDbClient);
    }
    async getSalesReport() {
        try {
            const salesResult = await this.docClient.send(new lib_dynamodb_1.ScanCommand({ TableName: this.salesTable }));
            const sales = salesResult.Items || [];
            const totalSales = sales.length;
            const totalRevenue = sales.reduce((sum, sale) => sum + (sale.total || 0), 0);
            const salesByType = {
                direct: sales.filter((sale) => sale.type === 'direct').length,
                reseller: sales.filter((sale) => sale.type === 'reseller').length,
            };
            const ticketsSold = sales.reduce((sum, sale) => sum + (sale.quantity || 0), 0);
            const salesByEvent = {};
            for (const sale of sales) {
                const eventId = sale.eventId;
                if (!salesByEvent[eventId]) {
                    const event = await this.eventsService.findOne(eventId);
                    salesByEvent[eventId] = {
                        eventName: event?.name || 'Unknown',
                        from: event?.from || 'Unknown',
                        to: event?.to || 'Unknown',
                        totalSales: 0,
                        totalTickets: 0,
                        totalRevenue: 0,
                        batches: {},
                    };
                }
                salesByEvent[eventId].totalSales += 1;
                salesByEvent[eventId].totalTickets += sale.quantity;
                salesByEvent[eventId].totalRevenue += sale.total;
                const batchId = sale.batchId;
                if (!salesByEvent[eventId].batches[batchId]) {
                    const batch = await this.batchesService.findOne(eventId, batchId);
                    salesByEvent[eventId].batches[batchId] = {
                        batchName: batch?.name || 'Unknown',
                        ticketsSold: 0,
                        revenue: 0,
                    };
                }
                salesByEvent[eventId].batches[batchId].ticketsSold += sale.quantity;
                salesByEvent[eventId].batches[batchId].revenue += sale.total;
            }
            return {
                totalSales,
                totalRevenue,
                ticketsSold,
                salesByType,
                salesByEvent,
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error al generar reporte de ventas', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getSaleDetails(saleId) {
        try {
            const sale = await this.docClient.send(new lib_dynamodb_1.GetCommand({
                TableName: this.salesTable,
                Key: { id: saleId },
            }));
            if (!sale.Item) {
                throw new common_1.HttpException('Venta no encontrada', common_1.HttpStatus.NOT_FOUND);
            }
            const tickets = await this.docClient.send(new lib_dynamodb_1.ScanCommand({
                TableName: 'Tickets-v2',
                FilterExpression: 'saleId = :saleId',
                ExpressionAttributeValues: { ':saleId': saleId },
            }));
            const user = await this.usersService.getUserProfile(sale.Item.userId);
            const reseller = sale.Item.resellerId
                ? await this.usersService.getUserProfile(sale.Item.resellerId)
                : null;
            const event = await this.eventsService.findOne(sale.Item.eventId);
            const batch = await this.batchesService.findOne(sale.Item.eventId, sale.Item.batchId);
            if (!event) {
                throw new common_1.HttpException('Evento no encontrado', common_1.HttpStatus.NOT_FOUND);
            }
            if (!batch) {
                throw new common_1.HttpException('Tanda no encontrada', common_1.HttpStatus.NOT_FOUND);
            }
            return {
                sale: sale.Item,
                tickets: tickets.Items || [],
                buyer: {
                    id: user.id,
                    role: user.role,
                    purchasedTickets: user.purchasedTickets,
                },
                reseller: reseller
                    ? {
                        id: reseller.id,
                        role: reseller.role,
                        soldTickets: reseller.soldTickets,
                    }
                    : null,
                event: {
                    id: event.id,
                    name: event.name,
                    from: event.from,
                    to: event.to,
                },
                batch: { id: batch.batchId, name: batch.name },
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al obtener detalles de venta', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getUsersReport() {
        try {
            const users = await this.usersService.getAllUsers();
            return users;
        }
        catch (error) {
            throw new common_1.HttpException('Error al generar reporte de usuarios', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.ReportsService = ReportsService;
exports.ReportsService = ReportsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)('DYNAMODB_CLIENT')),
    __metadata("design:paramtypes", [client_dynamodb_1.DynamoDBClient,
        sales_service_1.SalesService,
        tickets_service_1.TicketsService,
        users_service_1.UsersService,
        events_service_1.EventsService,
        batches_service_1.BatchesService])
], ReportsService);
//# sourceMappingURL=reports.service.js.map