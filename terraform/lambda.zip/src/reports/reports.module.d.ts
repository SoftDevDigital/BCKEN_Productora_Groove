export declare class ReportsModule {
}
