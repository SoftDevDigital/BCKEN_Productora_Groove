"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_ses_1 = require("@aws-sdk/client-ses");
const client_s3_1 = require("@aws-sdk/client-s3");
const uuid_1 = require("uuid");
const events_service_1 = require("../events/events.service");
const batches_service_1 = require("../batches/batches.service");
const tickets_service_1 = require("../tickets/tickets.service");
const users_service_1 = require("../users/users.service");
const config_1 = require("@nestjs/config");
const payments_service_1 = require("../payments/payments.service");
let SalesService = class SalesService {
    dynamoDbClient;
    eventsService;
    batchesService;
    ticketsService;
    usersService;
    configService;
    paymentsService;
    tableName = 'Sales-v2';
    docClient;
    sesClient;
    s3Client;
    constructor(dynamoDbClient, eventsService, batchesService, ticketsService, usersService, configService, paymentsService) {
        this.dynamoDbClient = dynamoDbClient;
        this.eventsService = eventsService;
        this.batchesService = batchesService;
        this.ticketsService = ticketsService;
        this.usersService = usersService;
        this.configService = configService;
        this.paymentsService = paymentsService;
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDbClient);
        this.sesClient = new client_ses_1.SESClient({
            region: this.configService.get('AWS_REGION'),
        });
        this.s3Client = new client_s3_1.S3Client({
            region: this.configService.get('AWS_REGION'),
        });
    }
    async createSale(createSaleDto, userId, email, resellerId, resellerEmail) {
        const saleId = (0, uuid_1.v4)();
        const { eventId, batchId, quantity, type, buyerEmailOrAlias, resellerId: providedResellerId, } = createSaleDto;
        let finalUserId = userId;
        let finalEmail = email;
        if (type === 'reseller' && buyerEmailOrAlias) {
            const user = await this.usersService.getUserByEmailOrAlias(buyerEmailOrAlias);
            if (!user) {
                throw new common_1.HttpException('El email o alias del comprador no está registrado', common_1.HttpStatus.BAD_REQUEST);
            }
            finalUserId = user.id;
            finalEmail = user.email;
        }
        const event = await this.eventsService.findOne(eventId);
        if (!event) {
            throw new common_1.HttpException('Evento no encontrado', common_1.HttpStatus.NOT_FOUND);
        }
        const batch = await this.batchesService.findOne(eventId, batchId);
        if (!batch || batch.availableTickets < quantity) {
            throw new common_1.HttpException('No hay suficientes tickets en la tanda', common_1.HttpStatus.BAD_REQUEST);
        }
        const basePrice = batch.price || 10;
        let total = quantity * basePrice;
        let commission = 0;
        if (type === 'reseller') {
            const finalResellerId = resellerId || providedResellerId;
            if (!finalResellerId) {
                throw new common_1.HttpException('Se requiere resellerId para ventas por revendedor', common_1.HttpStatus.BAD_REQUEST);
            }
            commission = total * 0.1;
            total += commission;
        }
        const params = {
            TableName: this.tableName,
            Item: {
                id: saleId,
                userId: finalUserId,
                resellerId: type === 'reseller' ? resellerId || providedResellerId : null,
                eventId,
                batchId,
                quantity,
                type,
                basePrice,
                commission,
                total,
                status: 'pending',
                createdAt: new Date().toISOString(),
            },
        };
        try {
            await this.docClient.send(new lib_dynamodb_1.PutCommand(params));
            await this.usersService.createOrUpdateUser(finalUserId, 'User', finalEmail);
            if (type === 'reseller' && (resellerId || providedResellerId)) {
                await this.usersService.createOrUpdateUser(resellerId || providedResellerId, 'Reseller', resellerEmail || finalEmail);
            }
            return {
                id: saleId,
                eventId,
                batchId,
                quantity,
                type,
                basePrice,
                commission,
                total,
                status: 'pending',
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error al registrar la venta', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async confirmSale(saleId, paymentStatus, paymentId) {
        const sale = await this.docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: this.tableName,
            Key: { id: saleId },
        }));
        if (!sale.Item) {
            throw new common_1.HttpException('Venta no encontrada', common_1.HttpStatus.NOT_FOUND);
        }
        if (sale.Item.status !== 'pending') {
            throw new common_1.HttpException('Venta ya procesada', common_1.HttpStatus.BAD_REQUEST);
        }
        const updateParams = {
            TableName: this.tableName,
            Key: { id: saleId },
            UpdateExpression: 'SET #status = :status, #paymentId = :paymentId, #updatedAt = :updatedAt',
            ExpressionAttributeNames: {
                '#status': 'status',
                '#paymentId': 'paymentId',
                '#updatedAt': 'updatedAt',
            },
            ExpressionAttributeValues: {
                ':status': paymentStatus,
                ':paymentId': paymentId,
                ':updatedAt': new Date().toISOString(),
            },
            ReturnValues: 'ALL_NEW',
        };
        try {
            console.log('Updating sale status:', { saleId, paymentStatus });
            const result = await this.docClient.send(new lib_dynamodb_1.UpdateCommand(updateParams));
            if (paymentStatus === 'approved') {
                console.log('Decrementing tickets:', {
                    eventId: sale.Item.eventId,
                    batchId: sale.Item.batchId,
                });
                await this.batchesService.decrementTickets(sale.Item.eventId, sale.Item.batchId, sale.Item.quantity);
                console.log('Creating tickets for sale:', saleId);
                const tickets = await this.ticketsService.createTickets({
                    id: saleId,
                    userId: sale.Item.userId,
                    eventId: sale.Item.eventId,
                    batchId: sale.Item.batchId,
                    quantity: sale.Item.quantity,
                });
                const ticketIds = tickets.map((ticket) => ticket.ticketId);
                console.log('Updating user tickets:', {
                    userId: sale.Item.userId,
                    ticketIds,
                });
                await this.usersService.updateUserTickets(sale.Item.userId, ticketIds, sale.Item.resellerId);
                console.log('Fetching user profile:', sale.Item.userId);
                const user = await this.usersService.getUserProfile(sale.Item.userId);
                console.log('Fetching event:', sale.Item.eventId);
                const event = await this.eventsService.findOne(sale.Item.eventId);
                console.log('Fetching batch:', {
                    eventId: sale.Item.eventId,
                    batchId: sale.Item.batchId,
                });
                const batch = await this.batchesService.findOne(sale.Item.eventId, sale.Item.batchId);
                console.log('Preparing QR attachments:', ticketIds);
                const qrAttachments = await Promise.all(tickets.map(async (ticket, index) => {
                    const qrKey = ticket.qrS3Url.split('.amazonaws.com/')[1];
                    const s3Response = await this.s3Client.send(new client_s3_1.GetObjectCommand({
                        Bucket: this.configService.get('S3_BUCKET') ||
                            'ticket-qr-bucket-dev-v2',
                        Key: qrKey,
                    }));
                    const body = await new Promise((resolve, reject) => {
                        const chunks = [];
                        s3Response.Body.on('data', (chunk) => chunks.push(chunk));
                        s3Response.Body.on('end', () => resolve(Buffer.concat(chunks)));
                        s3Response.Body.on('error', reject);
                    });
                    return {
                        ContentType: 'image/png',
                        Filename: `ticket-${index + 1}-${ticket.ticketId}.png`,
                        ContentID: `qr-${ticket.ticketId}`,
                        Content: body,
                    };
                }));
                console.log('Preparing email body');
                const emailBody = `
Hola ${user.alias || 'Usuario'},
Tu compra ha sido confirmada exitosamente.
**Comprobante de Pago**
- Venta ID: ${saleId}
- Evento: ${event?.name || 'Desconocido'}
- Tanda: ${batch?.name || 'Desconocida'}
- Cantidad de tickets: ${sale.Item.quantity}
- Precio por ticket: $${sale.Item.basePrice}
- Comisión: $${sale.Item.commission}
- Importe total abonado: $${sale.Item.total}
- Tickets: ${ticketIds.join(', ')}
**Códigos QR Únicos**
Los códigos QR de tus tickets están adjuntos en este correo.
¡Gracias por tu compra!
Equipo Groove Tickets
        `;
                const rawEmail = [
                    `From: ${this.configService.get('SES_EMAIL') || 'alexis@laikad.com'}`,
                    `To: ${user.email}`,
                    `Subject: Confirmación de Compra - ${event?.name || 'Evento'}`,
                    'MIME-Version: 1.0',
                    'Content-Type: multipart/mixed; boundary="boundary"',
                    '',
                    '--boundary',
                    'Content-Type: text/plain; charset=UTF-8',
                    '',
                    emailBody,
                    ...qrAttachments.map((attachment) => [
                        '--boundary',
                        `Content-Type: ${attachment.ContentType}`,
                        `Content-Disposition: attachment; filename="${attachment.Filename}"`,
                        `Content-Transfer-Encoding: base64`,
                        `Content-ID: <${attachment.ContentID}>`,
                        '',
                        attachment.Content.toString('base64'),
                    ].join('\n')),
                    '--boundary--',
                ].join('\n');
                console.log('Sending email to:', user.email);
                const emailParams = {
                    RawMessage: {
                        Data: Buffer.from(rawEmail),
                    },
                };
                await this.sesClient.send(new client_ses_1.SendRawEmailCommand(emailParams));
                console.log('Email sent successfully');
                return { ...result.Attributes, tickets };
            }
            return result.Attributes;
        }
        catch (error) {
            console.error('Error in confirmSale:', error);
            throw new common_1.HttpException(`Error al confirmar la venta: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async handleWebhook(paymentId) {
        const payment = await this.paymentsService.getPaymentStatus(paymentId);
        const status = payment.status;
        const saleId = payment.external_reference;
        if (!saleId) {
            throw new common_1.HttpException('No se encontró referencia de venta', common_1.HttpStatus.BAD_REQUEST);
        }
        await this.confirmSale(saleId, status, paymentId);
        return { status: 'processed', saleId, paymentStatus: status };
    }
};
exports.SalesService = SalesService;
exports.SalesService = SalesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)('DYNAMODB_CLIENT')),
    __metadata("design:paramtypes", [client_dynamodb_1.DynamoDBClient,
        events_service_1.EventsService,
        batches_service_1.BatchesService,
        tickets_service_1.TicketsService,
        users_service_1.UsersService,
        config_1.ConfigService,
        payments_service_1.PaymentsService])
], SalesService);
//# sourceMappingURL=sales.service.js.map