import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { SalesService } from '../sales/sales.service';
import { EventsService } from '../events/events.service';
import { BatchesService } from '../batches/batches.service';
import { ConfigService } from '@nestjs/config';
import { User } from './users/types';
export declare class UsersService {
    private readonly dynamoDbClient;
    private readonly salesService;
    private readonly eventsService;
    private readonly batchesService;
    private readonly configService;
    private readonly tableName;
    private readonly docClient;
    private readonly cognitoClient;
    constructor(dynamoDbClient: DynamoDBClient, salesService: SalesService, eventsService: EventsService, batchesService: BatchesService, configService: ConfigService);
    createOrUpdateUser(userId: string, role: string, email: string): Promise<{
        userId: string;
        role: string;
        email: string;
        purchasedTickets: never[];
        soldTickets: never[] | undefined;
    }>;
    updateUserTickets(userId: string, ticketIds: string[], resellerId?: string): Promise<Record<string, any> | undefined>;
    getUserProfile(userId: string): Promise<Record<string, any>>;
    getUserByEmailOrAlias(emailOrAlias: string): Promise<User | null>;
    getAllUsers(): Promise<User[]>;
    getUserPurchases(userId: string): Promise<{
        saleId: any;
        event: {
            id: any;
            name: any;
            from: any;
            to: any;
            location: any;
        } | null;
        batch: {
            id: any;
            name: any;
            price: any;
        } | null;
        quantity: any;
        total: any;
        status: any;
        tickets: any[];
        createdAt: any;
    }[]>;
}
