"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AWSSDKModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
let AWSSDKModule = class AWSSDKModule {
};
exports.AWSSDKModule = AWSSDKModule;
exports.AWSSDKModule = AWSSDKModule = __decorate([
    (0, common_1.Module)({
        providers: [
            {
                provide: 'DYNAMODB_CLIENT',
                useFactory: (configService) => {
                    return new client_dynamodb_1.DynamoDBClient({
                        region: configService.get('AWS_REGION') || 'us-east-1',
                    });
                },
                inject: [config_1.ConfigService],
            },
        ],
        exports: ['DYNAMODB_CLIENT'],
    })
], AWSSDKModule);
//# sourceMappingURL=aws-sdk.module.js.map