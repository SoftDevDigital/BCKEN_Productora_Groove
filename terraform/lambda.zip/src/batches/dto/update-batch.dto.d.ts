export declare class UpdateBatchDto {
    name?: string;
    totalTickets?: number;
    price?: number;
    isVip?: boolean;
    startTime?: string;
    endTime?: string;
}
