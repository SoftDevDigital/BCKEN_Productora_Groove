import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { CreateBatchDto } from './dto/create-batc.dto';
import { UpdateBatchDto } from './dto/update-batch.dto';
export declare class BatchesService {
    private readonly dynamoDbClient;
    private readonly tableName;
    private readonly docClient;
    constructor(dynamoDbClient: DynamoDBClient);
    create(eventId: string, createBatchDto: CreateBatchDto): Promise<{
        name: string;
        totalTickets: number;
        price: number;
        isVip: boolean;
        startTime: string;
        endTime: string;
        batchId: string;
    }>;
    findAll(eventId: string): Promise<Record<string, any>[]>;
    findOne(eventId: string, batchId: string): Promise<Record<string, any> | undefined>;
    update(eventId: string, batchId: string, updateBatchDto: UpdateBatchDto): Promise<Record<string, any> | undefined>;
    remove(eventId: string, batchId: string): Promise<boolean>;
    decrementTickets(eventId: string, batchId: string, quantity: number): Promise<Record<string, any> | undefined>;
}
