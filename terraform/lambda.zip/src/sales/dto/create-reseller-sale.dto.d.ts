export declare class CreateResellerSaleDto {
    eventId: string;
    batchId: string;
    quantity: number;
    buyerInfo: string;
}
