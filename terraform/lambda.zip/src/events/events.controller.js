"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a, _b;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const events_service_1 = require("./events.service");
const create_event_dto_1 = require("./dto/create-event.dto");
const update_event_dto_1 = require("./dto/update-event.dto");
const search_dto_1 = require("./dto/search.dto");
const multer_1 = require("multer");
let EventsController = class EventsController {
    eventsService;
    constructor(eventsService) {
        this.eventsService = eventsService;
    }
    getClaims(req) {
        let claims = null;
        if (req['apiGateway']) {
            const ctx = req['apiGateway'].event.requestContext;
            claims = ctx.authorizer?.jwt?.claims || ctx.authorizer?.claims || null;
        }
        if (!claims) {
            const token = req.headers['authorization']?.replace('Bearer ', '');
            if (token) {
                claims = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
            }
        }
        return claims;
    }
    ensureAdmin(claims) {
        const userRole = claims?.['custom:role'] || 'User';
        if (userRole !== 'Admin') {
            throw new common_1.HttpException('No autorizado: Requiere rol Admin', common_1.HttpStatus.FORBIDDEN);
        }
    }
    async create(createEventDto, image, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            if (image) {
                createEventDto.image = image;
            }
            const event = await this.eventsService.create(createEventDto);
            return {
                statusCode: common_1.HttpStatus.CREATED,
                message: 'Evento creado exitosamente',
                data: event,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException(`Error al crear evento: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findAll() {
        try {
            const events = await this.eventsService.findAll();
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Eventos obtenidos exitosamente',
                data: events,
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error al obtener eventos', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async search(query) {
        try {
            const events = await this.eventsService.search(query);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Búsqueda de eventos realizada exitosamente',
                data: events,
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error al buscar eventos', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findOne(id) {
        try {
            const event = await this.eventsService.findOne(id);
            if (!event) {
                throw new common_1.HttpException('Evento no encontrado', common_1.HttpStatus.NOT_FOUND);
            }
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Evento obtenido exitosamente',
                data: event,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al obtener evento', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async update(id, updateEventDto, image, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            if (image) {
                updateEventDto.image = image;
            }
            const updatedEvent = await this.eventsService.update(id, updateEventDto);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Evento actualizado exitosamente',
                data: updatedEvent,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException(`Error al actualizar evento: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async remove(id, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            const event = await this.eventsService.findOne(id);
            if (!event) {
                throw new common_1.HttpException('Evento no encontrado', common_1.HttpStatus.NOT_FOUND);
            }
            const result = await this.eventsService.delete(id);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: result.message,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al eliminar evento y sus tandas', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.EventsController = EventsController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image')),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.UploadedFile)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_event_dto_1.CreateEventDto, typeof (_a = typeof multer_1.Multer !== "undefined" && multer_1.Multer.File) === "function" ? _a : Object, Object]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('search'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true, whitelist: true })),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [search_dto_1.SearchEventDto]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "search", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, common_1.UsePipes)(new common_1.ValidationPipe({ transform: true })),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image')),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.UploadedFile)()),
    __param(3, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_event_dto_1.UpdateEventDto, typeof (_b = typeof multer_1.Multer !== "undefined" && multer_1.Multer.File) === "function" ? _b : Object, Object]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EventsController.prototype, "remove", null);
exports.EventsController = EventsController = __decorate([
    (0, common_1.Controller)('events'),
    __metadata("design:paramtypes", [events_service_1.EventsService])
], EventsController);
//# sourceMappingURL=events.controller.js.map