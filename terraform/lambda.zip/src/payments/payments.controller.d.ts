import { PaymentsService } from './payments.service';
import { SalesService } from '../sales/sales.service';
import type { Response } from 'express';
import { ConfigService } from '@nestjs/config';
export declare class PaymentsController {
    private readonly paymentsService;
    private readonly salesService;
    private readonly configService;
    constructor(paymentsService: PaymentsService, salesService: SalesService, configService: ConfigService);
    handleSuccess(saleId: string, paymentId: string, res: Response): Promise<void>;
    handleFailure(saleId: string, paymentId: string, res: Response): Promise<void>;
    handlePending(saleId: string, paymentId: string, res: Response): Promise<void>;
}
