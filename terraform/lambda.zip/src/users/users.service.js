"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const sales_service_1 = require("../sales/sales.service");
const events_service_1 = require("../events/events.service");
const batches_service_1 = require("../batches/batches.service");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const config_1 = require("@nestjs/config");
let UsersService = class UsersService {
    dynamoDbClient;
    salesService;
    eventsService;
    batchesService;
    configService;
    tableName = 'Users-v2';
    docClient;
    cognitoClient;
    constructor(dynamoDbClient, salesService, eventsService, batchesService, configService) {
        this.dynamoDbClient = dynamoDbClient;
        this.salesService = salesService;
        this.eventsService = eventsService;
        this.batchesService = batchesService;
        this.configService = configService;
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDbClient);
        this.cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
            region: this.configService.get('AWS_REGION') || 'us-east-1',
        });
    }
    async createOrUpdateUser(userId, role, email) {
        const params = {
            TableName: this.tableName,
            Item: {
                id: userId,
                role,
                email,
                purchasedTickets: [],
                soldTickets: role === 'Reseller' ? [] : undefined,
                createdAt: new Date().toISOString(),
            },
        };
        try {
            await this.docClient.send(new lib_dynamodb_1.PutCommand(params));
            return {
                userId,
                role,
                email,
                purchasedTickets: [],
                soldTickets: role === 'Reseller' ? [] : undefined,
            };
        }
        catch (error) {
            throw new common_1.HttpException('Error al crear/actualizar usuario', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async updateUserTickets(userId, ticketIds, resellerId) {
        const updateExpressionParts = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        updateExpressionParts.push('SET #purchasedTickets = list_append(if_not_exists(#purchasedTickets, :empty_list), :ticketIds)');
        expressionAttributeNames['#purchasedTickets'] = 'purchasedTickets';
        expressionAttributeValues[':ticketIds'] = ticketIds;
        expressionAttributeValues[':empty_list'] = [];
        if (resellerId) {
            updateExpressionParts.push('SET #soldTickets = list_append(if_not_exists(#soldTickets, :empty_list), :ticketIds)');
            expressionAttributeNames['#soldTickets'] = 'soldTickets';
        }
        const params = {
            TableName: this.tableName,
            Key: { id: userId },
            UpdateExpression: updateExpressionParts.join(', '),
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.UpdateCommand(params));
            return result.Attributes;
        }
        catch (error) {
            throw new common_1.HttpException('Error al actualizar tickets de usuario', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getUserProfile(userId) {
        const params = {
            TableName: this.tableName,
            Key: { id: userId },
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.GetCommand(params));
            if (!result.Item) {
                throw new common_1.HttpException('Usuario no encontrado', common_1.HttpStatus.NOT_FOUND);
            }
            return result.Item;
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al obtener perfil', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getUserByEmailOrAlias(emailOrAlias) {
        const params = {
            TableName: this.tableName,
            FilterExpression: 'email = :value OR alias = :value',
            ExpressionAttributeValues: {
                ':value': emailOrAlias,
            },
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.ScanCommand(params));
            return result.Items && result.Items.length > 0
                ? result.Items[0]
                : null;
        }
        catch (error) {
            throw new common_1.HttpException('Error al buscar usuario por email o alias', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getAllUsers() {
        const params = {
            TableName: this.tableName,
        };
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.ScanCommand(params));
            const users = result.Items || [];
            const enrichedUsers = await Promise.all(users.map(async (user) => {
                try {
                    const command = new client_cognito_identity_provider_1.AdminGetUserCommand({
                        UserPoolId: this.configService.get('COGNITO_USER_POOL_ID'),
                        Username: user.id,
                    });
                    const cognitoUser = await this.cognitoClient.send(command);
                    const attributes = cognitoUser.UserAttributes?.reduce((acc, attr) => ({ ...acc, [attr.Name]: attr.Value }), {}) || {};
                    return {
                        ...user,
                        given_name: attributes['given_name'] || 'N/A',
                        family_name: attributes['family_name'] || 'N/A',
                        email: attributes['email'] || user.email,
                    };
                }
                catch (error) {
                    console.error(`Error fetching Cognito data for user ${user.id}:`, error);
                    return {
                        ...user,
                        given_name: 'N/A',
                        family_name: 'N/A',
                        email: user.email,
                    };
                }
            }));
            return enrichedUsers;
        }
        catch (error) {
            throw new common_1.HttpException('Error al listar usuarios', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getUserPurchases(userId) {
        try {
            const salesResult = await this.docClient.send(new lib_dynamodb_1.ScanCommand({
                TableName: 'Sales-v2',
                FilterExpression: 'userId = :userId',
                ExpressionAttributeValues: { ':userId': userId },
            }));
            const sales = salesResult.Items || [];
            const purchases = await Promise.all(sales.map(async (sale) => {
                const event = await this.eventsService.findOne(sale.eventId);
                const batch = await this.batchesService.findOne(sale.eventId, sale.batchId);
                const ticketsResult = await this.docClient.send(new lib_dynamodb_1.ScanCommand({
                    TableName: 'Tickets-v2',
                    FilterExpression: 'saleId = :saleId',
                    ExpressionAttributeValues: { ':saleId': sale.id },
                }));
                const tickets = ticketsResult.Items || [];
                return {
                    saleId: sale.id,
                    event: event
                        ? {
                            id: event.id,
                            name: event.name,
                            from: event.from,
                            to: event.to,
                            location: event.location,
                        }
                        : null,
                    batch: batch
                        ? { id: batch.batchId, name: batch.name, price: batch.price }
                        : null,
                    quantity: sale.quantity,
                    total: sale.total,
                    status: sale.status,
                    tickets: tickets.map((ticket) => ticket.id),
                    createdAt: sale.createdAt,
                };
            }));
            return purchases;
        }
        catch (error) {
            throw new common_1.HttpException('Error al obtener compras del usuario', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)('DYNAMODB_CLIENT')),
    __param(1, (0, common_1.Inject)((0, common_1.forwardRef)(() => sales_service_1.SalesService))),
    __metadata("design:paramtypes", [client_dynamodb_1.DynamoDBClient,
        sales_service_1.SalesService,
        events_service_1.EventsService,
        batches_service_1.BatchesService,
        config_1.ConfigService])
], UsersService);
//# sourceMappingURL=users.service.js.map