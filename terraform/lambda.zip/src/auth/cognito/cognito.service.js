"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CognitoService = void 0;
const common_1 = require("@nestjs/common");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const config_1 = require("@nestjs/config");
const crypto = __importStar(require("crypto"));
let CognitoService = class CognitoService {
    configService;
    client;
    lastResend = {};
    validRoles = ['User', 'Reseller', 'Admin'];
    constructor(configService) {
        this.configService = configService;
        this.client = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
            region: this.configService.get('AWS_REGION'),
        });
    }
    getSecretHash(username) {
        const clientId = this.configService.get('COGNITO_CLIENT_ID');
        const clientSecret = this.configService.get('COGNITO_CLIENT_SECRET');
        if (!clientSecret) {
            throw new Error('COGNITO_CLIENT_SECRET is not defined');
        }
        const message = username + clientId;
        return crypto
            .createHmac('sha256', clientSecret)
            .update(message)
            .digest('base64');
    }
    async signUp(name, last_name, email, password) {
        try {
            const secretHash = this.getSecretHash(email);
            const command = new client_cognito_identity_provider_1.SignUpCommand({
                ClientId: this.configService.get('COGNITO_CLIENT_ID'),
                Username: email,
                Password: password,
                SecretHash: secretHash,
                UserAttributes: [
                    { Name: 'email', Value: email },
                    { Name: 'given_name', Value: name },
                    { Name: 'family_name', Value: last_name },
                    { Name: 'custom:country', Value: 'default' },
                    { Name: 'custom:role', Value: 'User' },
                ],
            });
            const result = await this.client.send(command);
            return {
                UserSub: result.UserSub,
                CodeDeliveryDetails: result.CodeDeliveryDetails,
            };
        }
        catch (error) {
            if (error.name === 'UsernameExistsException') {
                throw error;
            }
            if (error.name === 'InvalidParameterException') {
                throw new common_1.BadRequestException('Parámetros inválidos: verifica email o password.');
            }
            if (error.name === 'LimitExceededException') {
                throw new common_1.BadRequestException('Límite de solicitudes alcanzado. Intenta más tarde.');
            }
            throw new common_1.InternalServerErrorException('Error interno al registrar usuario.');
        }
    }
    async signIn(email, password) {
        try {
            const secretHash = this.getSecretHash(email);
            const command = new client_cognito_identity_provider_1.InitiateAuthCommand({
                AuthFlow: 'USER_PASSWORD_AUTH',
                ClientId: this.configService.get('COGNITO_CLIENT_ID'),
                AuthParameters: {
                    USERNAME: email,
                    PASSWORD: password,
                    SECRET_HASH: secretHash,
                },
            });
            return this.client.send(command);
        }
        catch (error) {
            if (error.name === 'NotAuthorizedException') {
                throw new common_1.BadRequestException('Credenciales incorrectas.');
            }
            if (error.name === 'UserNotConfirmedException') {
                throw new common_1.BadRequestException('Usuario no confirmado. Verifica tu email.');
            }
            throw new common_1.InternalServerErrorException('Error interno al iniciar sesión.');
        }
    }
    async adminAssignRole(userSub, role) {
        try {
            if (!this.validRoles.includes(role)) {
                throw new common_1.BadRequestException('Rol inválido. Use: User, Reseller o Admin.');
            }
            const command = new client_cognito_identity_provider_1.AdminUpdateUserAttributesCommand({
                UserPoolId: this.configService.get('COGNITO_USER_POOL_ID'),
                Username: userSub,
                UserAttributes: [{ Name: 'custom:role', Value: role }],
            });
            return this.client.send(command);
        }
        catch (error) {
            if (error instanceof common_1.BadRequestException) {
                throw error;
            }
            throw new common_1.InternalServerErrorException('Error al asignar rol.');
        }
    }
    async confirmSignUp(email, confirmationCode) {
        try {
            const secretHash = this.getSecretHash(email);
            const command = new client_cognito_identity_provider_1.ConfirmSignUpCommand({
                ClientId: this.configService.get('COGNITO_CLIENT_ID'),
                Username: email,
                ConfirmationCode: confirmationCode,
                SecretHash: secretHash,
            });
            return this.client.send(command);
        }
        catch (error) {
            if (error.name === 'CodeMismatchException') {
                throw new common_1.BadRequestException('Código de verificación incorrecto.');
            }
            if (error.name === 'ExpiredCodeException') {
                throw new common_1.BadRequestException('Código expirado. Solicita uno nuevo.');
            }
            throw new common_1.InternalServerErrorException('Error al confirmar email.');
        }
    }
    async resendConfirmation(email) {
        try {
            const now = Date.now();
            const lastResendTime = this.lastResend[email] || 0;
            if (now - lastResendTime < 60000) {
                throw new common_1.BadRequestException('Debes esperar 1 minuto desde el último reenvío.');
            }
            const secretHash = this.getSecretHash(email);
            const command = new client_cognito_identity_provider_1.ResendConfirmationCodeCommand({
                ClientId: this.configService.get('COGNITO_CLIENT_ID'),
                Username: email,
                SecretHash: secretHash,
            });
            const result = await this.client.send(command);
            this.lastResend[email] = now;
            return result;
        }
        catch (error) {
            if (error.name === 'UserNotFoundException') {
                throw new common_1.BadRequestException('Usuario no encontrado. Regístrate primero.');
            }
            throw new common_1.InternalServerErrorException('Error al reenviar código.');
        }
    }
    async adminConfirmSignUp(username) {
        try {
            const command = new client_cognito_identity_provider_1.AdminConfirmSignUpCommand({
                UserPoolId: this.configService.get('COGNITO_USER_POOL_ID'),
                Username: username,
            });
            return this.client.send(command);
        }
        catch (error) {
            throw new common_1.InternalServerErrorException('Error al confirmar usuario manualmente.');
        }
    }
};
exports.CognitoService = CognitoService;
exports.CognitoService = CognitoService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], CognitoService);
//# sourceMappingURL=cognito.service.js.map