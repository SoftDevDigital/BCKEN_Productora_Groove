export declare class SalesModule {
}
