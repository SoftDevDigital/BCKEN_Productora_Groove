export declare class CreateSaleDto {
    eventId: string;
    batchId: string;
    quantity: number;
    type: 'direct' | 'reseller';
    resellerId?: string;
    buyerEmailOrAlias?: string;
}
