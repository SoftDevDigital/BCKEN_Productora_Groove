import { HttpStatus } from '@nestjs/common';
import { TicketsService } from './tickets.service';
import type { Request } from 'express';
export declare class TicketsController {
    private readonly ticketsService;
    constructor(ticketsService: TicketsService);
    private getClaims;
    private ensureAdmin;
    validateTicket(ticketId: string, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: Record<string, any>;
    }>;
    getTicketQr(ticketId: string, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            qrS3Url: any;
        };
    }>;
    scanTickets(body: {
        ticketIds: string[];
    }, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            ticketId: string;
            status: "valid" | "invalid";
            message: string;
            ticket?: any;
        }[];
    }>;
}
