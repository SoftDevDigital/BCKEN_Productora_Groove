export declare class CreateQrDto {
    title: string;
    amount: number;
    generateQrImage?: boolean;
    saleId: string;
}
