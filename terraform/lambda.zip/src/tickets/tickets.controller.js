"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketsController = void 0;
const common_1 = require("@nestjs/common");
const tickets_service_1 = require("./tickets.service");
let TicketsController = class TicketsController {
    ticketsService;
    constructor(ticketsService) {
        this.ticketsService = ticketsService;
    }
    getClaims(req) {
        let claims = null;
        if (req['apiGateway']) {
            const ctx = req['apiGateway'].event.requestContext;
            claims = ctx.authorizer?.jwt?.claims || ctx.authorizer?.claims || null;
        }
        if (!claims) {
            const token = req.headers['authorization']?.replace('Bearer ', '');
            if (token) {
                claims = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
            }
        }
        return claims;
    }
    ensureAdmin(claims) {
        const userRole = claims?.['custom:role'] || 'User';
        if (userRole !== 'Admin') {
            throw new common_1.HttpException('No autorizado: Requiere rol Admin', common_1.HttpStatus.FORBIDDEN);
        }
    }
    async validateTicket(ticketId, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            const ticket = await this.ticketsService.validateTicket(ticketId);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Ticket válido',
                data: ticket,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al validar ticket', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getTicketQr(ticketId, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            const ticket = await this.ticketsService.validateTicket(ticketId);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'QR del ticket obtenido',
                data: { qrS3Url: ticket.qrS3Url },
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al obtener QR del ticket', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async scanTickets(body, req) {
        try {
            const claims = this.getClaims(req);
            this.ensureAdmin(claims);
            if (!body.ticketIds ||
                !Array.isArray(body.ticketIds) ||
                body.ticketIds.length === 0) {
                throw new common_1.HttpException('Se requiere una lista de ticketIds', common_1.HttpStatus.BAD_REQUEST);
            }
            const results = await this.ticketsService.scanTickets(body.ticketIds);
            return {
                statusCode: common_1.HttpStatus.OK,
                message: 'Tickets escaneados',
                data: results,
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Error al escanear tickets', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.TicketsController = TicketsController;
__decorate([
    (0, common_1.Get)('validate/:ticketId'),
    __param(0, (0, common_1.Param)('ticketId')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "validateTicket", null);
__decorate([
    (0, common_1.Get)(':ticketId/qr'),
    __param(0, (0, common_1.Param)('ticketId')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "getTicketQr", null);
__decorate([
    (0, common_1.Post)('admin/scan'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TicketsController.prototype, "scanTickets", null);
exports.TicketsController = TicketsController = __decorate([
    (0, common_1.Controller)('tickets'),
    __metadata("design:paramtypes", [tickets_service_1.TicketsService])
], TicketsController);
//# sourceMappingURL=tickets.controller.js.map