import { HttpStatus } from '@nestjs/common';
import { EventsService } from './events.service';
import { CreateEventDto } from './dto/create-event.dto';
import { UpdateEventDto } from './dto/update-event.dto';
import { SearchEventDto } from './dto/search.dto';
import type { Request } from 'express';
import { Multer } from 'multer';
export declare class EventsController {
    private readonly eventsService;
    constructor(eventsService: EventsService);
    private getClaims;
    private ensureAdmin;
    create(createEventDto: CreateEventDto, image: Multer.File, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            image: undefined;
            imageUrl: string | undefined;
            name: string;
            from: string;
            to: string;
            location: string;
            description?: string;
            id: string;
        };
    }>;
    findAll(): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: Record<string, any>[];
    }>;
    search(query: SearchEventDto): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: Record<string, any>[];
    }>;
    findOne(id: string): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: Record<string, any>;
    }>;
    update(id: string, updateEventDto: UpdateEventDto, image: Multer.File, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            image: undefined;
        };
    }>;
    remove(id: string, req: Request): Promise<{
        statusCode: HttpStatus;
        message: string;
    }>;
}
